
package l8ac1.L8AC1;


public class Runner {

   
    public static void main(String[] args) {
        
        student s = new student ( " UMAR ", " S-098 ", 054, " SP20-BSE-098 ", 568   );
         s.display();
}
    }
    

